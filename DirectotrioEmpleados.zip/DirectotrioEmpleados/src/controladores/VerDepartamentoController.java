package controladores;

import java.sql.*;
import javax.swing.table.DefaultTableModel;
import modelos.DataManager;

public class VerDepartamentoController {
    
    public void verDepartamento (String... datos) throws SQLException{
        DataManager manejador = new DataManager();
        String sql = String.format("INSERT INTO Departamentos("
                + "nombre, jefe_departamento, telefono_departamento"
                + ") VALUES('%s', '%s', '%s')", datos);
        manejador.ejecutarConsulta(sql);
    }
    
    public DefaultTableModel  cargarDepartamentos() throws SQLException {
        String [] columnas = {
            "Nombre",
            "Jefe del departamento", 
            "Telefono"
        };
        DefaultTableModel modelo = new DefaultTableModel(null, columnas);
        DataManager manejador = new DataManager();
        ResultSet datos = manejador.obtenerDatos("SELECT * FROM Departamentos");
        String[] registro = new String[3];
        while(datos.next()){
            registro[0] = datos.getString("nombre");
            registro[1] = datos.getString("jefe_departamento");
            registro[2] = datos.getString("telefono_departamento");
            modelo.addRow(registro);
        }
        manejador.cerrar();
        return modelo;
    }
}
