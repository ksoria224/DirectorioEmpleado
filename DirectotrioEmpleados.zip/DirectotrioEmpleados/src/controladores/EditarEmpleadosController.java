package controladores;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import modelos.DataManager;

public class EditarEmpleadosController {
    
    public DefaultTableModel cargarEmpleados() throws SQLException {
        String [] columnas = {
            "Id",
            "Nombre",
            "Correo", 
            "Telefono",
            "Cubiculo",
            "Jefatura",
            "Departamento ID",
            "Departamento"
        };
        DefaultTableModel modelo = new DefaultTableModel(null, columnas);
        DataManager manejador = new DataManager();
        ResultSet datos = manejador.obtenerDatos("SELECT * FROM Empleados");
        String[] registro = new String[8];
        while(datos.next()){
            registro[0] = String.valueOf(datos.getInt("id"));
            registro[1] = datos.getString("nombre");
            registro[2] = datos.getString("correo");
            registro[3] = datos.getString("telefono");
            registro[4] = datos.getString("cubiculo");
            registro[5] = String.valueOf(datos.getInt("es_jefe"));
            registro[6] = String.valueOf(datos.getInt("departamento_id"));
            registro[7] = datos.getString("nombre_departamento");
            modelo.addRow(registro);
        }
        manejador.cerrar();
        return modelo;
    }
    
    public void actualizarEmpleado(int id, String... datos) throws SQLException{
        DataManager manejador = new DataManager();
        String sql = "UPDATE Empleados SET "
            + "nombre='" + datos[0] + "', "
            + "correo='" + datos[1] + "', "
            + "telefono='" + datos[2] + "', "
            + "cubiculo='" + datos[3] + "', "
            + "es_jefe=" + datos[4] + ", "
            + "departamento_id=" + datos[5] + ", "
            + "nombre_departamento='" + datos[6] + "' "
            + "WHERE id=" + id;
        manejador.ejecutarConsulta(sql);
    }
    
    public void eliminarEmpleado(int id) throws SQLException{
        DataManager manejador = new DataManager();
        String sql = "DELETE FROM Empleados WHERE id="+id;
        manejador.ejecutarConsulta(sql);
    }
}
