package controladores;

import java.sql.*;
import javax.swing.table.DefaultTableModel;
import modelos.DataManager;

public class VerEmpleadoController {
    
    public void verEmpleado (String... datos) throws SQLException{
        DataManager manejador = new DataManager();
        String sql = String.format("INSERT INTO Empleados("
                + "nombre, correo, telefono, cubiculo, es_jefe, departamento_id, nombre_departamento"
                + ") VALUES('%s', '%s', '%s', '%s', %s, %s, '%s')", datos);
        manejador.ejecutarConsulta(sql);
    }
    
    public DefaultTableModel  cargarEmpleados() throws SQLException {
        String [] columnas = {
            "Nombre",
            "Correo", 
            "Telefono",
            "Cubiculo",
            "Jefatura",
            "Departamento ID",
            "Departamento"
        };
        DefaultTableModel modelo = new DefaultTableModel(null, columnas);
        DataManager manejador = new DataManager();
        ResultSet datos = manejador.obtenerDatos("SELECT * FROM Empleados");
        String[] registro = new String[7];
        while(datos.next()){
            registro[0] = datos.getString("nombre");
            registro[1] = datos.getString("correo");
            registro[2] = datos.getString("telefono");
            registro[3] = datos.getString("cubiculo");
            registro[4] = String.valueOf(datos.getInt("es_jefe"));
            registro[5] = String.valueOf(datos.getInt("departamento_id"));
            registro[6] = datos.getString("nombre_departamento");
            modelo.addRow(registro);
        }
        manejador.cerrar();
        return modelo;
    }
   public DefaultTableModel cargarEmpleadosSegunDepartamento(String nombreDepartamentoSeleccionado) throws SQLException {
        // Cargar los empleados del departamento seleccionado
        String[] columnas = {
            "Nombre",
            "Correo",
            "Telefono",
            "Cubiculo",
            "Jefatura",
            "Departamento ID",
            "Departamento"
        };
        DefaultTableModel modelo = new DefaultTableModel(null, columnas);
        DataManager manejador = new DataManager();
        String sql = String.format("SELECT * FROM Empleados WHERE nombre_departamento = '%s'", nombreDepartamentoSeleccionado);
        ResultSet datos = manejador.obtenerDatos(sql);
        String[] registro = new String[7];
        while (datos.next()) {
            registro[0] = datos.getString("nombre");
            registro[1] = datos.getString("correo");
            registro[2] = datos.getString("telefono");
            registro[3] = datos.getString("cubiculo");
            registro[4] = String.valueOf(datos.getInt("es_jefe"));
            registro[5] = String.valueOf(datos.getInt("departamento_id"));
            registro[6] = datos.getString("nombre_departamento");
            modelo.addRow(registro);
        }
        manejador.cerrar();
        return modelo;
    }
   
    public DefaultTableModel cargarEmpleadosPorNombre(String nombreEmpleadoSeleccionado) throws SQLException {
        String[] columnas = {
            "Nombre",
            "Correo",
            "Telefono",
            "Cubiculo",
            "Jefatura",
            "Departamento ID",
            "Departamento"
        };
        DefaultTableModel modelo = new DefaultTableModel(null, columnas);
        DataManager manejador = new DataManager();
        String sql = String.format("SELECT * FROM Empleados WHERE nombre LIKE '%%%s%%'", nombreEmpleadoSeleccionado);
        ResultSet datos = manejador.obtenerDatos(sql);
        String[] registro = new String[7];
        while (datos.next()) {
            registro[0] = datos.getString("nombre");
            registro[1] = datos.getString("correo");
            registro[2] = datos.getString("telefono");
            registro[3] = datos.getString("cubiculo");
            registro[4] = String.valueOf(datos.getInt("es_jefe"));
            registro[5] = String.valueOf(datos.getInt("departamento_id"));
            registro[6] = datos.getString("nombre_departamento");
            modelo.addRow(registro);
        }
        manejador.cerrar();
        return modelo;
    }
}

