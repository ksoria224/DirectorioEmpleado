package controladores;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import modelos.DataManager;

public class EditarDepartamentosController {
    
    public DefaultTableModel cargarDepartamentos() throws SQLException {
        String [] columnas = {
            "Id",
            "Nombre",
            "Jefe del departamento", 
            "Telefono"

        };
        DefaultTableModel modelo = new DefaultTableModel(null, columnas);
        DataManager manejador = new DataManager();
        ResultSet datos = manejador.obtenerDatos("SELECT * FROM Departamentos");
        String[] registro = new String[8];
        while(datos.next()){
            registro[0] = String.valueOf(datos.getInt("id"));
            registro[1] = datos.getString("nombre");
            registro[2] = datos.getString("jefe_departamento");
            registro[3] = datos.getString("telefono_departamento");
            modelo.addRow(registro);
        }
        manejador.cerrar();
        return modelo;
    }
    
    public void actualizarDepartamento(int id, String... datos) throws SQLException{
        DataManager manejador = new DataManager();
        String sql = "UPDATE Departamentos SET "
            + "nombre='" + datos[0] + "', "
            + "jefe_departamento='" + datos[1] + "', "
            + "telefono_departamento='" + datos[2] + "' "
            + "WHERE id=" + id;
        manejador.ejecutarConsulta(sql);
    }
    
    public void eliminarDepartamento(int id) throws SQLException{
        DataManager manejador = new DataManager();
        String sql = "DELETE FROM Departamentos WHERE id="+id;
        manejador.ejecutarConsulta(sql);
    }
}
