package DirectorioEmpleados;
//Creado por Kevin Santiago Soria Garcia 
public class DirectorioEmpledos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new vistas.Ingreso().setVisible(true);
    }
    
}
