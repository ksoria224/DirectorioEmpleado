
package vistas;

import controladores.VerEmpleadoController;
import java.awt.Graphics;
import java.awt.Image;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;


public class VerEmpleadosInternalFrame extends javax.swing.JInternalFrame {

    FondoPanel fondo = new FondoPanel();
    
    public VerEmpleadosInternalFrame() {
        this.setContentPane(fondo);
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtNombre = new javax.swing.JTextField();
        txtCorreo = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        txtCubiculo = new javax.swing.JTextField();
        txtJefatura = new javax.swing.JTextField();
        txtIDDepartamento = new javax.swing.JTextField();
        txtDepartamento = new javax.swing.JTextField();
        btnCrearEmpleado = new javax.swing.JButton();
        btnMostrarEmpleados = new javax.swing.JButton();
        panelProductos = new javax.swing.JScrollPane();
        tblEmpleados = new javax.swing.JTable();
        btnMostrarEmpleadosDpto = new javax.swing.JButton();
        btnMostrarEmpleadosNombre = new javax.swing.JButton();

        setClosable(true);
        setTitle("Ver Empleados");

        txtNombre.setToolTipText("");
        txtNombre.setBorder(javax.swing.BorderFactory.createTitledBorder("Nombre"));

        txtCorreo.setBorder(javax.swing.BorderFactory.createTitledBorder("Correo"));

        txtTelefono.setBorder(javax.swing.BorderFactory.createTitledBorder("Telefono"));

        txtCubiculo.setBorder(javax.swing.BorderFactory.createTitledBorder("Cubiculo"));

        txtJefatura.setBorder(javax.swing.BorderFactory.createTitledBorder("Nivel de jefatura"));

        txtIDDepartamento.setBorder(javax.swing.BorderFactory.createTitledBorder("ID Departamento"));

        txtDepartamento.setBorder(javax.swing.BorderFactory.createTitledBorder("Departamento"));

        btnCrearEmpleado.setText("Crear Empleado");
        btnCrearEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearEmpleadoActionPerformed(evt);
            }
        });

        btnMostrarEmpleados.setText("Mostrar Empleados");
        btnMostrarEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarEmpleadosActionPerformed(evt);
            }
        });

        tblEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Correo", "Telefono", "Cubiculo", "Jefatura", "Departamento ID", "Departamento"
            }
        ));
        panelProductos.setViewportView(tblEmpleados);
        tblEmpleados.getAccessibleContext().setAccessibleName("");
        tblEmpleados.getAccessibleContext().setAccessibleDescription("");

        btnMostrarEmpleadosDpto.setText("Mostrar Empleados Por Departamento");
        btnMostrarEmpleadosDpto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarEmpleadosDptoActionPerformed(evt);
            }
        });

        btnMostrarEmpleadosNombre.setText("Mostrar Empleado Por Nombre");
        btnMostrarEmpleadosNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarEmpleadosNombreActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCubiculo, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(txtNombre, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 266, Short.MAX_VALUE)
                        .addComponent(txtCorreo, javax.swing.GroupLayout.Alignment.LEADING)))
                .addGap(138, 138, 138)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtIDDepartamento, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtJefatura, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDepartamento, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnMostrarEmpleados)
                            .addComponent(btnMostrarEmpleadosDpto)
                            .addComponent(btnMostrarEmpleadosNombre))
                        .addGap(23, 23, 23))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnCrearEmpleado)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(panelProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 964, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtJefatura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIDDepartamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnMostrarEmpleadosNombre))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDepartamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnMostrarEmpleados)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnMostrarEmpleadosDpto)))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCubiculo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCrearEmpleado))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panelProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(94, Short.MAX_VALUE))
        );

        txtNombre.getAccessibleContext().setAccessibleName("");
        txtCorreo.getAccessibleContext().setAccessibleName("");

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCrearEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearEmpleadoActionPerformed
        VerEmpleadoController controlador = new VerEmpleadoController();
        String [] datos = {
            txtNombre.getText(),
            txtCorreo.getText(),
            txtTelefono.getText(),
            txtCubiculo.getText(),
            txtJefatura.getText(),
            txtIDDepartamento.getText(),
            txtDepartamento.getText()
        };
        try {
            controlador.verEmpleado(datos);
            listarProductos();
        } catch (SQLException ex) {
            Logger.getLogger(VerEmpleadosInternalFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnCrearEmpleadoActionPerformed

    private void btnMostrarEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarEmpleadosActionPerformed
        listarProductos();
    }//GEN-LAST:event_btnMostrarEmpleadosActionPerformed

    private void btnMostrarEmpleadosDptoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarEmpleadosDptoActionPerformed
      
    String nombreDepartamentoSeleccionado = txtDepartamento.getText();

   
    VerEmpleadoController controlador = new VerEmpleadoController();
    try {
        DefaultTableModel modeloEmpleados = controlador.cargarEmpleadosSegunDepartamento(nombreDepartamentoSeleccionado);
        
        
        if (modeloEmpleados != null) {
            tblEmpleados.setModel(modeloEmpleados);
        } else {
            
            JOptionPane.showMessageDialog(this, "No se encontraron empleados para el departamento: " + nombreDepartamentoSeleccionado, "Departamento Vacío", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (SQLException ex) {
        
        JOptionPane.showMessageDialog(this, "Error al cargar los empleados del departamento: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnMostrarEmpleadosDptoActionPerformed

    private void btnMostrarEmpleadosNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarEmpleadosNombreActionPerformed
        String nombreEmpleadoSeleccionado = txtNombre.getText();

   
    VerEmpleadoController controlador = new VerEmpleadoController();
    try {
        DefaultTableModel modeloEmpleados = controlador.cargarEmpleadosPorNombre(nombreEmpleadoSeleccionado);
        
        
        if (modeloEmpleados != null) {
            tblEmpleados.setModel(modeloEmpleados);
        } else {
          
            JOptionPane.showMessageDialog(this, "No se encontraron empleados con el nombre: " + nombreEmpleadoSeleccionado, "Empleado no encontrado", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (SQLException ex) {
        
        JOptionPane.showMessageDialog(this, "Error al cargar los empleados: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnMostrarEmpleadosNombreActionPerformed

    private void listarProductos(){
        VerEmpleadoController controlador = new VerEmpleadoController();
        try {
            tblEmpleados.setModel(controlador.cargarEmpleados());
        } catch (SQLException ex) {
            Logger.getLogger(VerEmpleadosInternalFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCrearEmpleado;
    private javax.swing.JButton btnMostrarEmpleados;
    private javax.swing.JButton btnMostrarEmpleadosDpto;
    private javax.swing.JButton btnMostrarEmpleadosNombre;
    private javax.swing.JScrollPane panelProductos;
    private javax.swing.JTable tblEmpleados;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtCubiculo;
    private javax.swing.JTextField txtDepartamento;
    private javax.swing.JTextField txtIDDepartamento;
    private javax.swing.JTextField txtJefatura;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
 class FondoPanel extends JPanel
    {
        private Image imagen;
        
        @Override
        public void paint(Graphics g)
        {
            imagen = new ImageIcon(getClass().getResource("/imagenes/red.jpg")).getImage();
            
            g.drawImage(imagen,0, 0, getWidth(), getHeight(),this);
            
            setOpaque(false);
            
            super.paint(g);
        }
    }
}
