
package vistas;

import controladores.VerDepartamentoController;
import java.awt.Graphics;
import java.awt.Image;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JPanel;


public class VerDepartamentosInternalFrame extends javax.swing.JInternalFrame {

    FondoPanel fondo = new FondoPanel();
    
    public VerDepartamentosInternalFrame() {
        this.setContentPane(fondo);
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtNombreDep = new javax.swing.JTextField();
        txtJefeDep = new javax.swing.JTextField();
        txtTelefonoDep = new javax.swing.JTextField();
        btnCrearDepartamento = new javax.swing.JButton();
        btnMostrarDepartamentos = new javax.swing.JButton();
        panelProductos = new javax.swing.JScrollPane();
        tblDepartamentos = new javax.swing.JTable();

        setClosable(true);
        setTitle("Ver Departamentos");

        txtNombreDep.setToolTipText("");
        txtNombreDep.setBorder(javax.swing.BorderFactory.createTitledBorder("Nombre"));

        txtJefeDep.setBorder(javax.swing.BorderFactory.createTitledBorder("Jefe Departamento"));
        txtJefeDep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtJefeDepActionPerformed(evt);
            }
        });

        txtTelefonoDep.setBorder(javax.swing.BorderFactory.createTitledBorder("Telefono"));

        btnCrearDepartamento.setText("Crear Departamento");
        btnCrearDepartamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearDepartamentoActionPerformed(evt);
            }
        });

        btnMostrarDepartamentos.setText("Mostrar Departamentos");
        btnMostrarDepartamentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarDepartamentosActionPerformed(evt);
            }
        });

        tblDepartamentos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Jefe del departamento", "Telefono del departamento"
            }
        ));
        panelProductos.setViewportView(tblDepartamentos);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtTelefonoDep, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(txtNombreDep, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 266, Short.MAX_VALUE)
                        .addComponent(txtJefeDep, javax.swing.GroupLayout.Alignment.LEADING)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 207, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnMostrarDepartamentos)
                    .addComponent(btnCrearDepartamento))
                .addGap(345, 345, 345))
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(panelProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 964, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNombreDep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCrearDepartamento))
                .addGap(26, 26, 26)
                .addComponent(txtJefeDep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(txtTelefonoDep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(btnMostrarDepartamentos)))
                .addGap(68, 68, 68)
                .addComponent(panelProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(95, Short.MAX_VALUE))
        );

        txtNombreDep.getAccessibleContext().setAccessibleName("");
        txtJefeDep.getAccessibleContext().setAccessibleName("");

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCrearDepartamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearDepartamentoActionPerformed
        VerDepartamentoController controlador = new VerDepartamentoController();
        String [] datos = {
            txtNombreDep.getText(),
            txtJefeDep.getText(),
            txtTelefonoDep.getText(),

        };
        try {
            controlador.verDepartamento(datos);
            listarProductos();
        } catch (SQLException ex) {
            Logger.getLogger(VerDepartamentosInternalFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnCrearDepartamentoActionPerformed

    private void btnMostrarDepartamentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarDepartamentosActionPerformed
        listarProductos();
    }//GEN-LAST:event_btnMostrarDepartamentosActionPerformed

    private void txtJefeDepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtJefeDepActionPerformed
       
    }//GEN-LAST:event_txtJefeDepActionPerformed

    private void listarProductos(){
        VerDepartamentoController controlador = new VerDepartamentoController();
        try {
            tblDepartamentos.setModel(controlador.cargarDepartamentos());
        } catch (SQLException ex) {
            Logger.getLogger(VerDepartamentosInternalFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCrearDepartamento;
    private javax.swing.JButton btnMostrarDepartamentos;
    private javax.swing.JScrollPane panelProductos;
    private javax.swing.JTable tblDepartamentos;
    private javax.swing.JTextField txtJefeDep;
    private javax.swing.JTextField txtNombreDep;
    private javax.swing.JTextField txtTelefonoDep;
    // End of variables declaration//GEN-END:variables
 class FondoPanel extends JPanel
    {
        private Image imagen;
        
        @Override
        public void paint(Graphics g)
        {
            imagen = new ImageIcon(getClass().getResource("/imagenes/red.jpg")).getImage();
            
            g.drawImage(imagen,0, 0, getWidth(), getHeight(),this);
            
            setOpaque(false);
            
            super.paint(g);
        }
    }
}
