
package vistas;

import java.awt.Graphics;
import java.awt.Image;
import java.beans.PropertyVetoException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;


public class PrincipalV extends javax.swing.JFrame {
    
    FondoPanel fondo = new FondoPanel();
    
 
    public PrincipalV() {
        this.setContentPane(fondo);
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelContenedor = new FondoPanel();
        menuPrincipal = new javax.swing.JMenuBar();
        mnuEmpleados = new javax.swing.JMenu();
        menuEmpleadosCrear = new javax.swing.JMenuItem();
        menuEmpleadosEditar = new javax.swing.JMenuItem();
        mnuProductos1 = new javax.swing.JMenu();
        menuDepartamentosCrear = new javax.swing.JMenuItem();
        menuDepartamentosEditar = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Directorio Empleados");

        panelContenedor.setBackground(new java.awt.Color(153, 255, 255));

        javax.swing.GroupLayout panelContenedorLayout = new javax.swing.GroupLayout(panelContenedor);
        panelContenedor.setLayout(panelContenedorLayout);
        panelContenedorLayout.setHorizontalGroup(
            panelContenedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1024, Short.MAX_VALUE)
        );
        panelContenedorLayout.setVerticalGroup(
            panelContenedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 728, Short.MAX_VALUE)
        );

        menuPrincipal.setBackground(new java.awt.Color(51, 51, 255));

        mnuEmpleados.setText("Empleados ");

        menuEmpleadosCrear.setBackground(new java.awt.Color(4, 92, 154));
        menuEmpleadosCrear.setText("Ver Empleados");
        menuEmpleadosCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuEmpleadosCrearActionPerformed(evt);
            }
        });
        mnuEmpleados.add(menuEmpleadosCrear);

        menuEmpleadosEditar.setBackground(new java.awt.Color(4, 92, 154));
        menuEmpleadosEditar.setText("Editar Empleados");
        menuEmpleadosEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuEmpleadosEditarActionPerformed(evt);
            }
        });
        mnuEmpleados.add(menuEmpleadosEditar);

        menuPrincipal.add(mnuEmpleados);

        mnuProductos1.setText("Departamentos");

        menuDepartamentosCrear.setBackground(new java.awt.Color(4, 92, 154));
        menuDepartamentosCrear.setText("Ver Departamentos");
        menuDepartamentosCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuDepartamentosCrearActionPerformed(evt);
            }
        });
        mnuProductos1.add(menuDepartamentosCrear);

        menuDepartamentosEditar.setBackground(new java.awt.Color(4, 92, 154));
        menuDepartamentosEditar.setText("Editar Departamentos");
        menuDepartamentosEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuDepartamentosEditarActionPerformed(evt);
            }
        });
        mnuProductos1.add(menuDepartamentosEditar);

        menuPrincipal.add(mnuProductos1);

        setJMenuBar(menuPrincipal);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelContenedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelContenedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void menuEmpleadosCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuEmpleadosCrearActionPerformed
        VerEmpleadosInternalFrame crear = new VerEmpleadosInternalFrame();
        cargarFormulario(crear);
    }//GEN-LAST:event_menuEmpleadosCrearActionPerformed

    private void menuEmpleadosEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuEmpleadosEditarActionPerformed
        EditarEmpleadoInternalFrame editar = new EditarEmpleadoInternalFrame();
        cargarFormulario(editar);
    }//GEN-LAST:event_menuEmpleadosEditarActionPerformed

    private void menuDepartamentosCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuDepartamentosCrearActionPerformed
        VerDepartamentosInternalFrame crearDep = new VerDepartamentosInternalFrame();
        cargarFormulario(crearDep);// TODO add your handling code here:
    }//GEN-LAST:event_menuDepartamentosCrearActionPerformed

    private void menuDepartamentosEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuDepartamentosEditarActionPerformed
        EditarDeparatmentoInternalFrame editarDep = new EditarDeparatmentoInternalFrame();
        cargarFormulario(editarDep);// TODO add your handling code here:// TODO add your handling code here:
    }//GEN-LAST:event_menuDepartamentosEditarActionPerformed

    private void cargarFormulario(JInternalFrame ventana){
        panelContenedor.removeAll();
        panelContenedor.add(ventana);
        ventana.setVisible(true);
        try {
            ventana.setMaximum(true);
        } catch (PropertyVetoException ex) {
            Logger.getLogger(PrincipalV.class.getName()).log(Level.SEVERE, null, ex);
        }
        panelContenedor.updateUI();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PrincipalV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PrincipalV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PrincipalV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PrincipalV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PrincipalV().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem menuDepartamentosCrear;
    private javax.swing.JMenuItem menuDepartamentosEditar;
    private javax.swing.JMenuItem menuEmpleadosCrear;
    private javax.swing.JMenuItem menuEmpleadosEditar;
    private javax.swing.JMenuBar menuPrincipal;
    private javax.swing.JMenu mnuEmpleados;
    private javax.swing.JMenu mnuProductos1;
    private javax.swing.JPanel panelContenedor;
    // End of variables declaration//GEN-END:variables

 class FondoPanel extends JPanel
    {
        private Image imagen;
        
        @Override
        public void paint(Graphics g)
        {
            imagen = new ImageIcon(getClass().getResource("/imagenes/empleados.jpg")).getImage();
            
            g.drawImage(imagen,0, 0, getWidth(), getHeight(),this);
            
            setOpaque(false);
            
            super.paint(g);
        }
    }
}

