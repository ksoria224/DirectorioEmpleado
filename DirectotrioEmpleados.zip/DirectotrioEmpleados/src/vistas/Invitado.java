
package vistas;

import java.awt.Graphics;
import java.awt.Image;
import java.beans.PropertyVetoException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;


public class Invitado extends javax.swing.JFrame {
    
    FondoPanel fondo = new FondoPanel();
    
 
    public Invitado (){
        this.setContentPane(fondo);
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelContenedorINV = new FondoPanel();
        menuPrincipalInv = new javax.swing.JMenuBar();
        mnuEmpleadosINV = new javax.swing.JMenu();
        menuEmpleadosINV = new javax.swing.JMenuItem();
        mnuDepartamentosINV = new javax.swing.JMenu();
        menuDepartamentosINV = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Directorio Empleados");

        panelContenedorINV.setBackground(new java.awt.Color(153, 255, 255));

        javax.swing.GroupLayout panelContenedorINVLayout = new javax.swing.GroupLayout(panelContenedorINV);
        panelContenedorINV.setLayout(panelContenedorINVLayout);
        panelContenedorINVLayout.setHorizontalGroup(
            panelContenedorINVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1024, Short.MAX_VALUE)
        );
        panelContenedorINVLayout.setVerticalGroup(
            panelContenedorINVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 728, Short.MAX_VALUE)
        );

        menuPrincipalInv.setBackground(new java.awt.Color(51, 51, 255));

        mnuEmpleadosINV.setText("Empleados ");

        menuEmpleadosINV.setBackground(new java.awt.Color(4, 92, 154));
        menuEmpleadosINV.setText("Ver Empleados");
        menuEmpleadosINV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuEmpleadosINVActionPerformed(evt);
            }
        });
        mnuEmpleadosINV.add(menuEmpleadosINV);

        menuPrincipalInv.add(mnuEmpleadosINV);

        mnuDepartamentosINV.setText("Departamentos");

        menuDepartamentosINV.setBackground(new java.awt.Color(4, 92, 154));
        menuDepartamentosINV.setText("Ver Departamentos");
        menuDepartamentosINV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuDepartamentosINVActionPerformed(evt);
            }
        });
        mnuDepartamentosINV.add(menuDepartamentosINV);

        menuPrincipalInv.add(mnuDepartamentosINV);

        setJMenuBar(menuPrincipalInv);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelContenedorINV, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelContenedorINV, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void menuEmpleadosINVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuEmpleadosINVActionPerformed
        VerEmpleadosInvitadoInternalFrame Ver = new VerEmpleadosInvitadoInternalFrame();
        cargarFormulario(Ver);
    }//GEN-LAST:event_menuEmpleadosINVActionPerformed

    private void menuDepartamentosINVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuDepartamentosINVActionPerformed
        VerDepartamentoInvitadoInternalFrame VerDep = new VerDepartamentoInvitadoInternalFrame();
        cargarFormulario(VerDep);// TODO add your handling code here:
    }//GEN-LAST:event_menuDepartamentosINVActionPerformed

    private void cargarFormulario(JInternalFrame ventana){
        panelContenedorINV.removeAll();
        panelContenedorINV.add(ventana);
        ventana.setVisible(true);
        try {
            ventana.setMaximum(true);
        } catch (PropertyVetoException ex) {
            Logger.getLogger(Invitado.class.getName()).log(Level.SEVERE, null, ex);
        }
        panelContenedorINV.updateUI();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
     
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Invitado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Invitado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Invitado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Invitado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Invitado().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem menuDepartamentosINV;
    private javax.swing.JMenuItem menuEmpleadosINV;
    private javax.swing.JMenuBar menuPrincipalInv;
    private javax.swing.JMenu mnuDepartamentosINV;
    private javax.swing.JMenu mnuEmpleadosINV;
    private javax.swing.JPanel panelContenedorINV;
    // End of variables declaration//GEN-END:variables

 class FondoPanel extends JPanel
    {
        private Image imagen;
        
        @Override
        public void paint(Graphics g)
        {
            imagen = new ImageIcon(getClass().getResource("/imagenes/empleados.jpg")).getImage();
            
            g.drawImage(imagen,0, 0, getWidth(), getHeight(),this);
            
            setOpaque(false);
            
            super.paint(g);
        }
    }
}

