
package vistas;

import controladores.VerEmpleadoController;
import java.awt.Graphics;
import java.awt.Image;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;


public class VerEmpleadosInvitadoInternalFrame extends javax.swing.JInternalFrame {

    FondoPanel fondo = new FondoPanel();
    
    public VerEmpleadosInvitadoInternalFrame() {
        this.setContentPane(fondo);
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtNombreINV = new javax.swing.JTextField();
        txtCorreoINV = new javax.swing.JTextField();
        txtTelefonoINV = new javax.swing.JTextField();
        txtCubiculoINV = new javax.swing.JTextField();
        txtJefaturaINV = new javax.swing.JTextField();
        txtIDDepartamentoINV = new javax.swing.JTextField();
        txtDepartamentoINV = new javax.swing.JTextField();
        btnMostrarEmpleadosINV = new javax.swing.JButton();
        panelProductosINV = new javax.swing.JScrollPane();
        tblEmpleadosINV = new javax.swing.JTable();
        btnMostrarEmpleadosDptoINV = new javax.swing.JButton();
        btnMostrarEmpleadosNombreINV = new javax.swing.JButton();

        setClosable(true);
        setTitle("Ver Empleados");

        txtNombreINV.setToolTipText("");
        txtNombreINV.setBorder(javax.swing.BorderFactory.createTitledBorder("Nombre"));

        txtCorreoINV.setBorder(javax.swing.BorderFactory.createTitledBorder("Correo"));

        txtTelefonoINV.setBorder(javax.swing.BorderFactory.createTitledBorder("Telefono"));

        txtCubiculoINV.setBorder(javax.swing.BorderFactory.createTitledBorder("Cubiculo"));

        txtJefaturaINV.setBorder(javax.swing.BorderFactory.createTitledBorder("Nivel de jefatura"));

        txtIDDepartamentoINV.setBorder(javax.swing.BorderFactory.createTitledBorder("ID Departamento"));

        txtDepartamentoINV.setBorder(javax.swing.BorderFactory.createTitledBorder("Departamento"));

        btnMostrarEmpleadosINV.setText("Mostrar Empleados");
        btnMostrarEmpleadosINV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarEmpleadosINVActionPerformed(evt);
            }
        });

        tblEmpleadosINV.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Correo", "Telefono", "Cubiculo", "Jefatura", "Departamento ID", "Departamento"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        panelProductosINV.setViewportView(tblEmpleadosINV);
        tblEmpleadosINV.getAccessibleContext().setAccessibleName("");
        tblEmpleadosINV.getAccessibleContext().setAccessibleDescription("");

        btnMostrarEmpleadosDptoINV.setText("Mostrar Empleados Por Departamento");
        btnMostrarEmpleadosDptoINV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarEmpleadosDptoINVActionPerformed(evt);
            }
        });

        btnMostrarEmpleadosNombreINV.setText("Mostrar Empleado Por Nombre");
        btnMostrarEmpleadosNombreINV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarEmpleadosNombreINVActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtTelefonoINV, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCubiculoINV, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(txtNombreINV, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 266, Short.MAX_VALUE)
                        .addComponent(txtCorreoINV, javax.swing.GroupLayout.Alignment.LEADING)))
                .addGap(138, 138, 138)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtIDDepartamentoINV, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtJefaturaINV, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDepartamentoINV, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnMostrarEmpleadosINV)
                    .addComponent(btnMostrarEmpleadosDptoINV)
                    .addComponent(btnMostrarEmpleadosNombreINV))
                .addGap(23, 23, 23))
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(panelProductosINV, javax.swing.GroupLayout.PREFERRED_SIZE, 964, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNombreINV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtJefaturaINV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtCorreoINV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIDDepartamentoINV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnMostrarEmpleadosNombreINV))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTelefonoINV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDepartamentoINV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnMostrarEmpleadosINV)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnMostrarEmpleadosDptoINV)))
                .addGap(27, 27, 27)
                .addComponent(txtCubiculoINV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panelProductosINV, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(95, Short.MAX_VALUE))
        );

        txtNombreINV.getAccessibleContext().setAccessibleName("");
        txtCorreoINV.getAccessibleContext().setAccessibleName("");

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnMostrarEmpleadosINVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarEmpleadosINVActionPerformed
        listarProductos();
    }//GEN-LAST:event_btnMostrarEmpleadosINVActionPerformed

    private void btnMostrarEmpleadosDptoINVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarEmpleadosDptoINVActionPerformed
      
    String nombreDepartamentoSeleccionado = txtDepartamentoINV.getText();

    
    VerEmpleadoController controlador = new VerEmpleadoController();
    try {
        DefaultTableModel modeloEmpleados = controlador.cargarEmpleadosSegunDepartamento(nombreDepartamentoSeleccionado);
       
        if (modeloEmpleados != null) {
            tblEmpleadosINV.setModel(modeloEmpleados);
        } else {
           
            JOptionPane.showMessageDialog(this, "No se encontraron empleados para el departamento: " + nombreDepartamentoSeleccionado, "Departamento Vacío", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (SQLException ex) {
        
        JOptionPane.showMessageDialog(this, "Error al cargar los empleados del departamento: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnMostrarEmpleadosDptoINVActionPerformed

    private void btnMostrarEmpleadosNombreINVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarEmpleadosNombreINVActionPerformed
        String nombreEmpleadoSeleccionado = txtNombreINV.getText();

   
    VerEmpleadoController controlador = new VerEmpleadoController();
    try {
        DefaultTableModel modeloEmpleados = controlador.cargarEmpleadosPorNombre(nombreEmpleadoSeleccionado);
        
        
        if (modeloEmpleados != null) {
            tblEmpleadosINV.setModel(modeloEmpleados);
        } else {
            
            JOptionPane.showMessageDialog(this, "No se encontraron empleados con el nombre: " + nombreEmpleadoSeleccionado, "Empleado no encontrado", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (SQLException ex) {
       
        JOptionPane.showMessageDialog(this, "Error al cargar los empleados: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnMostrarEmpleadosNombreINVActionPerformed

    private void listarProductos(){
        VerEmpleadoController controlador = new VerEmpleadoController();
        try {
            tblEmpleadosINV.setModel(controlador.cargarEmpleados());
        } catch (SQLException ex) {
            Logger.getLogger(VerEmpleadosInvitadoInternalFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnMostrarEmpleadosDptoINV;
    private javax.swing.JButton btnMostrarEmpleadosINV;
    private javax.swing.JButton btnMostrarEmpleadosNombreINV;
    private javax.swing.JScrollPane panelProductosINV;
    private javax.swing.JTable tblEmpleadosINV;
    private javax.swing.JTextField txtCorreoINV;
    private javax.swing.JTextField txtCubiculoINV;
    private javax.swing.JTextField txtDepartamentoINV;
    private javax.swing.JTextField txtIDDepartamentoINV;
    private javax.swing.JTextField txtJefaturaINV;
    private javax.swing.JTextField txtNombreINV;
    private javax.swing.JTextField txtTelefonoINV;
    // End of variables declaration//GEN-END:variables
 class FondoPanel extends JPanel
    {
        private Image imagen;
        
        @Override
        public void paint(Graphics g)
        {
            imagen = new ImageIcon(getClass().getResource("/imagenes/red.jpg")).getImage();
            
            g.drawImage(imagen,0, 0, getWidth(), getHeight(),this);
            
            setOpaque(false);
            
            super.paint(g);
        }
    }
}
