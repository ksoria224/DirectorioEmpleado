
package vistas;

import controladores.VerDepartamentoController;
import java.awt.Graphics;
import java.awt.Image;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JPanel;


public class VerDepartamentoInvitadoInternalFrame extends javax.swing.JInternalFrame {

    FondoPanel fondo = new FondoPanel();
    
    public VerDepartamentoInvitadoInternalFrame(){
        this.setContentPane(fondo);
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtNombreDepINV = new javax.swing.JTextField();
        txtJefeDepINV = new javax.swing.JTextField();
        txtTelefonoDepINV = new javax.swing.JTextField();
        btnMostrarDepartamentosINV = new javax.swing.JButton();
        panelDepartamentosinv = new javax.swing.JScrollPane();
        tblDepartamentosINV = new javax.swing.JTable();

        setClosable(true);
        setTitle("Ver Departamentos");

        txtNombreDepINV.setToolTipText("");
        txtNombreDepINV.setBorder(javax.swing.BorderFactory.createTitledBorder("Nombre"));

        txtJefeDepINV.setBorder(javax.swing.BorderFactory.createTitledBorder("Jefe Departamento"));
        txtJefeDepINV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtJefeDepINVActionPerformed(evt);
            }
        });

        txtTelefonoDepINV.setBorder(javax.swing.BorderFactory.createTitledBorder("Telefono"));

        btnMostrarDepartamentosINV.setText("Mostrar Departamentos");
        btnMostrarDepartamentosINV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarDepartamentosINVActionPerformed(evt);
            }
        });

        tblDepartamentosINV.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Jefe del departamento", "Telefono del departamento"
            }
        ));
        panelDepartamentosinv.setViewportView(tblDepartamentosINV);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtTelefonoDepINV, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(txtNombreDepINV, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 266, Short.MAX_VALUE)
                        .addComponent(txtJefeDepINV, javax.swing.GroupLayout.Alignment.LEADING)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 207, Short.MAX_VALUE)
                .addComponent(btnMostrarDepartamentosINV)
                .addGap(345, 345, 345))
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(panelDepartamentosinv, javax.swing.GroupLayout.PREFERRED_SIZE, 964, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(txtNombreDepINV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(txtJefeDepINV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(txtTelefonoDepINV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(btnMostrarDepartamentosINV)))
                .addGap(68, 68, 68)
                .addComponent(panelDepartamentosinv, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(95, Short.MAX_VALUE))
        );

        txtNombreDepINV.getAccessibleContext().setAccessibleName("");
        txtJefeDepINV.getAccessibleContext().setAccessibleName("");

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnMostrarDepartamentosINVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarDepartamentosINVActionPerformed
        listarProductos();
    }//GEN-LAST:event_btnMostrarDepartamentosINVActionPerformed

    private void txtJefeDepINVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtJefeDepINVActionPerformed
        
    }//GEN-LAST:event_txtJefeDepINVActionPerformed

    private void listarProductos(){
        VerDepartamentoController controlador = new VerDepartamentoController();
        try {
            tblDepartamentosINV.setModel(controlador.cargarDepartamentos());
        } catch (SQLException ex) {
            Logger.getLogger(VerDepartamentoInvitadoInternalFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnMostrarDepartamentosINV;
    private javax.swing.JScrollPane panelDepartamentosinv;
    private javax.swing.JTable tblDepartamentosINV;
    private javax.swing.JTextField txtJefeDepINV;
    private javax.swing.JTextField txtNombreDepINV;
    private javax.swing.JTextField txtTelefonoDepINV;
    // End of variables declaration//GEN-END:variables
 class FondoPanel extends JPanel
    {
        private Image imagen;
        
        @Override
        public void paint(Graphics g)
        {
            imagen = new ImageIcon(getClass().getResource("/imagenes/red.jpg")).getImage();
            
            g.drawImage(imagen,0, 0, getWidth(), getHeight(),this);
            
            setOpaque(false);
            
            super.paint(g);
        }
    }
}
